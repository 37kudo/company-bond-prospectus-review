"""Deterministic helpers for the company bond prospectus review skill."""
