#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
from typing import Any

PATTERNS = {
    "issuer_name": [r"发行人[：:]\s*([^\n，。]{2,80})", r"公司名称[：:]\s*([^\n，。]{2,80})"],
    "registered_amount": [r"注册(?:总)?金额[：:]?\s*([0-9,.]+\s*(?:亿元|万元|元))"],
    "issue_amount": [r"(?:本期|本次)发行(?:规模|金额)[：:]?\s*([0-9,.]+\s*(?:亿元|万元|元))"],
    "proceeds_amount": [r"(?:募集资金总额|拟使用募集资金|募集资金金额)[：:]?\s*([0-9,.]+\s*(?:亿元|万元|元))"],
    "maturity": [r"债券期限[：:]?\s*([^\n，。]{1,40})"],
    "lead_underwriter": [r"(?:牵头)?主承销商[：:]\s*([^\n，。]{2,80})"],
    "trustee": [r"受托管理人[：:]\s*([^\n，。]{2,80})"],
}


def extract_fields(text: str) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for field, patterns in PATTERNS.items():
        matches = []
        for pattern in patterns:
            matches.extend(m.group(1).strip() for m in re.finditer(pattern, text, flags=re.I))
        unique = list(dict.fromkeys(matches))
        result[field] = {
            "values": unique,
            "status": "missing" if not unique else "consistent" if len(unique) == 1 else "conflict",
        }
    return result


def detect_period_phrase_conflict(text: str) -> dict[str, Any]:
    phrases = [p for p in ("近三年及一期", "最近三年及一期", "近两年及一期", "最近两年及一期") if p in text]
    canonical = {p.replace("最近", "近") for p in phrases}
    return {"status": "conflict" if len(canonical) > 1 else "consistent", "phrases": phrases}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("text_file")
    args = parser.parse_args()
    print(json.dumps(extract_fields(open(args.text_file, encoding="utf-8").read()), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
