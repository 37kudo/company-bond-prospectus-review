#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import yaml

MANDATORY_TASKS = {"scope_check", "low_level_review"}


def _normalize(value: str) -> str:
    return "".join(str(value).strip().lower().replace("，", ",").split())


def _matches_selection(selected: set[str], task: dict[str, Any], fields: tuple[str, ...]) -> bool:
    if not selected:
        return True
    candidates: set[str] = set()
    for field in fields:
        value = task.get(field, [])
        values = value if isinstance(value, list) else [value]
        candidates.update(_normalize(item) for item in values if str(item).strip())
    for raw in selected:
        choice = _normalize(raw)
        if choice in {"全部", "全文", "all"}:
            return True
        if any(choice == candidate or choice in candidate or candidate in choice for candidate in candidates):
            return True
    return False


def load_tasks(path: str | Path) -> list[dict[str, Any]]:
    data = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    return list(data.get("tasks", []))


def route_tasks(
    tasks: list[dict[str, Any]],
    mode: str,
    selected_modules: list[str] | None = None,
    selected_chapters: list[str] | None = None,
    available_documents: list[str] | None = None,
) -> list[dict[str, Any]]:
    modules = {x.strip() for x in (selected_modules or []) if x.strip()}
    chapters = {x.strip() for x in (selected_chapters or []) if x.strip()}
    documents = set(available_documents or ["募集说明书"])
    routed = []
    for task in tasks:
        reason = None
        mandatory = task["task_id"] in MANDATORY_TASKS
        if not mandatory and mode not in task.get("review_modes", []):
            reason = "MODE_EXCLUDED"
        elif not mandatory and not _matches_selection(
            modules,
            task,
            ("task_id", "name_zh", "review_type", "output_group", "module_aliases"),
        ):
            reason = "MODULE_NOT_SELECTED"
        elif not mandatory and not _matches_selection(chapters, task, ("applicable_chapters", "name_zh")):
            reason = "CHAPTER_NOT_SELECTED"
        required = [d for d in task.get("applicable_documents", []) if d != "已上传的配套材料"]
        if reason is None and any(d not in documents for d in required):
            reason = "DOCUMENT_NOT_PROVIDED"
        routed.append({"task_id": task["task_id"], "run": reason is None, "reason_code": reason})
    return routed


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default=str(Path(__file__).resolve().parents[1] / "config" / "review_tasks.yaml"))
    parser.add_argument("--mode", required=True)
    parser.add_argument("--modules", nargs="*")
    parser.add_argument("--chapters", nargs="*")
    parser.add_argument("--documents", nargs="*")
    args = parser.parse_args()
    print(
        json.dumps(
            route_tasks(load_tasks(args.config), args.mode, args.modules, args.chapters, args.documents),
            ensure_ascii=False,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
