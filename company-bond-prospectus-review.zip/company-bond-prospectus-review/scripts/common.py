from __future__ import annotations

import json
import re
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any

SEVERITY_ORDER = {"高": 0, "中": 1, "低": 2, "提示": 3}
ALLOWED_UNITS = {
    "元": Decimal("1"),
    "千元": Decimal("1000"),
    "万元": Decimal("10000"),
    "亿元": Decimal("100000000"),
}


def decimal_value(value: Any) -> Decimal:
    if isinstance(value, Decimal):
        return value
    if value is None or isinstance(value, bool):
        raise ValueError("数值不能为空或布尔值")
    text = str(value).strip().replace(",", "").replace("，", "").replace("−", "-").replace("－", "-")
    if (text.startswith("(") and text.endswith(")")) or (text.startswith("（") and text.endswith("）")):
        text = "-" + text[1:-1]
    try:
        return Decimal(text)
    except InvalidOperation as exc:
        raise ValueError(f"无法解析数值：{value!r}") from exc


def convert_unit(value: Any, from_unit: str, to_unit: str) -> Decimal:
    if from_unit not in ALLOWED_UNITS or to_unit not in ALLOWED_UNITS:
        raise ValueError(f"不支持的单位：{from_unit} -> {to_unit}")
    return decimal_value(value) * ALLOWED_UNITS[from_unit] / ALLOWED_UNITS[to_unit]


def normalize_reporting_period(value: str) -> str:
    text = re.sub(r"\s+", "", value).replace("－", "-").replace("—", "-")
    text = text.replace("年末", "-12-31").replace("年初", "-01-01")
    match = re.fullmatch(r"(\d{4})年(\d{1,2})月(\d{1,2})日", text)
    if match:
        year, month, day = map(int, match.groups())
        return f"{year:04d}-{month:02d}-{day:02d}"
    return text


def load_json(path: str | Path) -> Any:
    resolved = Path(path).expanduser().resolve()
    return json.loads(resolved.read_text(encoding="utf-8"))


def write_json(path: str | Path, value: Any) -> None:
    resolved = Path(path).expanduser().resolve()
    resolved.parent.mkdir(parents=True, exist_ok=True)
    resolved.write_text(json.dumps(value, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
