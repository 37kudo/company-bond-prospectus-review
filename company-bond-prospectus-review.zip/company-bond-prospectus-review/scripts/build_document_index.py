#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
from typing import Any

HEADING = re.compile(
    r"^(第[一二三四五六七八九十百零〇0-9]+[章节]|[一二三四五六七八九十]+、|\([一二三四五六七八九十]+\)|（[一二三四五六七八九十]+）|#+)\s*(.+)$"
)


def build_index(documents: list[dict[str, Any]], chunk_chars: int = 6000) -> dict[str, Any]:
    indexed = []
    for doc in documents:
        text = str(doc.get("text", ""))
        headings = []
        offset = 0
        for line in text.splitlines(True):
            match = HEADING.match(line.strip())
            if match:
                headings.append({"title": line.strip(), "offset": offset})
            offset += len(line)
        chunks = [
            {
                "chunk_id": f"{doc.get('document_id', 'doc')}-{i}",
                "start": start,
                "end": min(start + chunk_chars, len(text)),
                "text": text[start : start + chunk_chars],
            }
            for i, start in enumerate(range(0, len(text), chunk_chars), 1)
        ]
        indexed.append(
            {
                **{k: v for k, v in doc.items() if k != "text"},
                "characters": len(text),
                "headings": headings,
                "chunks": chunks,
            }
        )
    return {"documents": indexed}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("documents_json")
    args = parser.parse_args()
    documents = json.loads(open(args.documents_json, encoding="utf-8").read())
    print(json.dumps(build_index(documents), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
