---
name: company-bond-prospectus-review
description: Review Chinese company bond prospectuses and uploaded supporting materials with evidence-backed chapter, special-topic, financial, low-level-error, cross-chapter, and cross-document checks. Use when Codex or ChatGPT Work needs to audit a 公司债券募集说明书 in quick, standard, deep, selected-chapter, or selected-module mode; reconcile financial figures deterministically; compare audit reports, trustee agreements, holder meeting rules, legal opinions, underwriting review opinions, rating reports, inquiry checklists, replies, contracts, approvals, articles, or other workpapers; and produce a structured Chinese review report without inventing missing evidence.
---

# 公司债募集说明书智能审核

以当前会话的原生文件读取与推理能力执行审核；仅让 `scripts/` 承担确定性索引、路由、计算、校验、去重和报告生成。不得在脚本中调用外部大模型、OCR 服务或执行待审核文档中的代码、宏和命令。

## 执行流程

1. 识别文件角色。读取 `references/input-contract.md`，优先按内容而非扩展名分类；必要时运行 `scripts/inspect_inputs.py`。募集说明书为必需，其余材料均为可选。
2. 读取文件。Word、Excel、文本型 PDF 优先使用原生读取；不得无条件先转 Markdown。无有效文本层、复杂表格或扫描页改用视觉读取/OCR，并保留页级证据；冲突时标记人工复核。
3. 选择模式和范围。读取 `references/review-modes.md`，再运行 `scripts/route_tasks.py` 或按 `config/review_tasks.yaml` 路由。支持快速、标准、深度，以及指定章节/专项。
4. 加载公共规则。始终读取：
   - `references/global-review-policy.md`
   - `references/evidence-policy.md`
   - `references/false-positive-policy.md`
   - `references/output-schema.md`
   - `references/context-contract.md`
5. 按路由结果加载每个任务的 `rule_file`。将文件内的 Dify 选择器按 `context-contract.md` 解析为当前会话证据，不要尝试调用旧节点。不要一次性加载全部规则；只加载当前模式和范围所需文件。
6. 提取核心字段并核对。可运行 `scripts/extract_core_fields.py`、`scripts/build_document_index.py`。数字、金额、日期、比例、单位和期间不得仅凭语言模型猜测。
7. 执行财务重算。需要时运行 `scripts/calculate_financial_metrics.py`、`scripts/reconcile_financial_data.py` 与 `scripts/compare_financial_records.py`；使用 Decimal、明确单位、期间和合并/母公司口径。受托协议争议解决条款使用 `scripts/compare_trustee_clauses.py` 做确定性初筛，再由会话结合双侧原文判断。
8. 输出前运行 `scripts/validate_issues.py`，再运行 `scripts/deduplicate_issues.py`。跨文件问题必须有双侧证据；未上传文件不得被认定为披露缺失。
9. 运行 `scripts/build_report.py` 或按 `assets/review-report-template.md` 生成报告。始终单列“低级错误与数据一致性专项核查”；未发现明确问题时也保留该节结论。

## 审核模式

- 快速审核：核心发行要素、重大事项、募集资金、发行人基本信息、主要财务数据、有息负债、担保、受限资产、诉讼、低级错误和核心跨章节一致性。
- 标准审核：全部章节、发行人专项、财务专项、财务重算、跨章节及已上传配套材料核对。
- 深度审核：在标准审核上逐份核对已上传审计报告和其他项目底稿。

用户指定模块或章节时只缩小专业任务范围，不得跳过适用范围识别、证据政策、问题校验和低级错误专项。

## 输出要求

按 `schemas/issue.schema.json` 形成问题对象，等级仅使用高、中、低、提示。重点输出需修改、可能被审核关注、影响投资者判断或申报质量的问题；抑制无实质影响的轻微格式差异。对证据不足、OCR 冲突或无法可靠复现的事项输出人工复核，不得补造事实。
