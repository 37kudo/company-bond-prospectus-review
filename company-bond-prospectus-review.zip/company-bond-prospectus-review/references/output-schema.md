# 问题输出规范

每个问题必须符合 `schemas/issue.schema.json`，至少包含：`issue_id`、`category`、`severity`、`document`、`chapter`、`location`、`source_excerpt`、`issue_description`、`comparison_evidence`、`calculation`、`suggested_revision`、`confidence`、`manual_review_required`、`related_task_ids`。

类别使用：事实错误、规则或披露缺失、跨章节不一致、跨文件不一致、财务计算错误、低级错误、表达优化、人工复核事项。

等级使用：高、中、低、提示。

问题描述必须具体；修改建议必须可执行；财务计算错误必须填 `calculation`。

跨文件问题的 `comparison_evidence` 必须使用双侧对象，不接受一段混合字符串：

```json
{
  "left": {"document": "募集说明书", "location": "第十三节/P120", "excerpt": "……"},
  "right": {"document": "受托管理协议", "location": "第20条/P18", "excerpt": "……"},
  "difference": "两侧争议解决机构不同"
}
```

两侧必须是不同且已上传成功读取的文件。仅有单侧证据时改为“人工复核事项”，不得认定跨文件不一致。
