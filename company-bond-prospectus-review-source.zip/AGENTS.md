# Maintenance instructions

- Treat `company-bond-prospectus-review/` as the installable Skill and keep `SKILL.md` concise.
- Keep detailed audit rules in `references/`, deterministic work in `scripts/`, routing in `config/review_tasks.yaml`, and contracts in `schemas/`.
- Never add external model or OCR calls, API keys, customer documents, source Dify exports, logs, or caches to the Skill ZIP.
- When the Dify source changes, rerun `tools/analyze_dify.py`, inspect the migration diff, run all tests, run the official `quick_validate.py`, then rebuild the ZIP.
- Every source node must remain represented in `build/dify_inventory.json` and `docs/migration-map.md`.
- Preserve the evidence, low-false-positive, missing-document, Decimal calculation, OCR conflict, path traversal and low-level-error safeguards.

