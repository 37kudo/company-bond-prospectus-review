#!/usr/bin/env python3
"""Build a complete, auditable inventory and migration map from a Dify DSL export."""

from __future__ import annotations

import argparse
import copy
import json
import re
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

import yaml

ROOT = Path(__file__).resolve().parents[1]
SKILL = ROOT / "company-bond-prospectus-review"


def compact(value: Any, limit: int = 220) -> str:
    text = json.dumps(value, ensure_ascii=False, separators=(",", ":"))
    text = text.replace("\n", "\\n")
    return text if len(text) <= limit else text[: limit - 1] + "…"


def safe_name(value: str) -> str:
    return re.sub(r"[^a-z0-9_-]+", "-", value.lower()).strip("-")


def rule_path(node_id: str, title: str) -> str:
    if node_id.startswith("financials_") or node_id == "finance_tasks":
        folder = "financial-rules"
    elif node_id.startswith("cross_check_"):
        folder = "cross-document-rules"
    elif node_id.startswith("issuer_basic_") or node_id in {"low_level_review", "scope_check"}:
        folder = "special-review-rules"
    else:
        folder = "chapter-rules"
    return f"references/{folder}/{safe_name(node_id)}.md"


def mapping_for(node: dict[str, Any]) -> tuple[str, str, str]:
    node_id = str(node["id"])
    data = node.get("data", {})
    node_type = data.get("type", "unknown")
    title = str(data.get("title", ""))
    if node_type == "start":
        return (
            "SKILL.md 输入契约；config/review_tasks.yaml",
            "已迁移",
            "文件角色、模式、章节和专项选择由 Skill 入口解释。",
        )
    if node_type == "end":
        return "scripts/build_report.py", "已迁移", "统一输出 Markdown/JSON/Word 大纲。"
    if node_type == "document-extractor":
        return (
            "scripts/inspect_inputs.py；scripts/build_document_index.py",
            "原生能力替代",
            "优先使用 ChatGPT Work/Codex 原生文件读取；扫描件降级为视觉/OCR与人工复核。",
        )
    if node_type == "llm":
        path = rule_path(node_id, title)
        return f"{path}；config/review_tasks.yaml", "已迁移", "模型推理由 Skill 执行；公共证据、误报和输出规则已去重。"
    if node_type == "if-else":
        return "scripts/route_tasks.py", "已合并", "42 个路由节点合并为配置驱动的统一任务路由器。"
    if node_type == "variable-aggregator":
        return (
            "scripts/deduplicate_issues.py；scripts/build_report.py",
            "已合并",
            "42 个二选一聚合节点合并为统一收集、去重、排序与报告机制。",
        )
    if node_type in {"iteration", "iteration-start"}:
        return (
            "scripts/inspect_inputs.py；scripts/build_document_index.py",
            "已合并",
            "多份审计报告按文件列表迭代，不依赖外部 OCR 服务。",
        )
    if node_type == "code":
        direct = {
            "template_rules": "config/review_tasks.yaml；references/",
            "core_fields": "scripts/extract_core_fields.py；references/context-contract.md",
            "cross_check": "scripts/reconcile_financial_data.py；scripts/compare_financial_records.py；references/cross-document-rules/",
            "finance_code": "scripts/calculate_financial_metrics.py；scripts/compare_financial_records.py",
            "report": "scripts/build_report.py",
            "report_clean": "scripts/build_report.py；scripts/validate_issues.py",
            "doc_retrieval": "scripts/build_document_index.py",
            "trustee_clause_compare": "scripts/compare_trustee_clauses.py；references/cross-document-rules/trustee-agreement.md",
            "review_issuer_basic": "scripts/deduplicate_issues.py；scripts/build_report.py",
            "review_financials": "scripts/deduplicate_issues.py；scripts/build_report.py",
            "financial_data_extract": "scripts/extract_core_fields.py",
            "financial_note_compare": "scripts/compare_financial_records.py",
            "audit_report_merge": "scripts/build_document_index.py",
            "core_terms_group": "scripts/build_report.py",
            "core_issuer_group": "scripts/build_report.py",
            "core_financial_group": "scripts/build_report.py",
            "core_protection_group": "scripts/build_report.py",
            "core_closing_group": "scripts/build_report.py",
            "prospectus_ch5_table_compare": "scripts/compare_financial_records.py",
            "financial_context_router": "scripts/route_tasks.py",
            "review_router": "scripts/route_tasks.py",
            "cross_check_prepare": "scripts/route_tasks.py",
        }
        if node_id.endswith("__skip"):
            return "scripts/route_tasks.py", "已合并", "跳过原因由统一 reason_code 输出，不再保留重复脚本。"
        target = direct.get(node_id, "scripts/route_tasks.py")
        fully_migrated = {"template_rules", "trustee_clause_compare", "review_router"}
        if node_id in fully_migrated:
            status = "已迁移"
        elif node_id in direct:
            status = "部分迁移"
        else:
            status = "已合并"
        note = (
            "确定性逻辑已由目标脚本覆盖。"
            if status == "已迁移"
            else "保留业务目标并合并到目标流程；源节点的 Dify 专用解析、字符串拼装或上下文裁剪实现不宣称逐行等价，需真实项目验证。"
        )
        return target, status, note
    return "docs/known-limitations.md", "已记录", "未知节点类型保留在机器库存中并要求人工复核。"


def strip_shared_prompt(text: str) -> str:
    text = re.sub(r"\n*重要：不要输出思考过程.*?严格 JSON。", "", text, flags=re.S)
    text = re.sub(r"\n*全局误报排除规则：.*", "", text, flags=re.S)
    text = re.sub(r"\n*\[Uploaded document retrieval\].*", "", text, flags=re.S)
    return text.strip()


def write_rule_file(node: dict[str, Any]) -> None:
    node_id = str(node["id"])
    data = node["data"]
    path = SKILL / rule_path(node_id, str(data.get("title", ""))).replace("references/", "references/", 1)
    path.parent.mkdir(parents=True, exist_ok=True)
    prompts = data.get("prompt_template") or []
    system = "\n\n".join(strip_shared_prompt(str(p.get("text", ""))) for p in prompts if p.get("role") == "system")
    user = "\n\n".join(strip_shared_prompt(str(p.get("text", ""))) for p in prompts if p.get("role") == "user")
    variables = data.get("variables") or []
    body = [
        f"# {data.get('title', node_id)}",
        "",
        *(
            [
                "> 迁移执行覆盖（优先于下方保留的源 Prompt 路由语句）：本专项在快速、标准、深度和指定章节/专项模式下均执行。指定章节只缩小其他专业任务，不关闭低级错误与数据一致性核查。",
                "",
            ]
            if node_id == "low_level_review"
            else []
        ),
        f"- 任务 ID：`{node_id}`",
        f"- 来源节点类型：`{data.get('type')}`",
        "- 执行要求：先加载 `global-review-policy.md`、`evidence-policy.md`、`false-positive-policy.md` 和 `output-schema.md`。",
        "",
        "## 专项规则",
        "",
        system or "按任务名称和配置的适用章节执行证据化审核。",
        "",
        "## 任务输入与输出提示",
        "",
        user or "仅基于已读取材料输出结构化问题。",
        "",
        "## Dify 变量引用",
        "",
        "```json",
        json.dumps(variables, ensure_ascii=False, indent=2),
        "```",
        "",
    ]
    path.write_text("\n".join(body), encoding="utf-8")


def task_from_llm(node: dict[str, Any]) -> dict[str, Any]:
    node_id = str(node["id"])
    title = str(node["data"].get("title", node_id))
    if node_id.startswith("review_"):
        review_type = "chapter"
    elif node_id.startswith("issuer_basic_"):
        review_type = "issuer_special"
    elif node_id.startswith("financials_") or node_id == "finance_tasks":
        review_type = "financial"
    elif node_id.startswith("cross_check_"):
        review_type = "cross_chapter"
    elif node_id == "low_level_review":
        review_type = "low_level"
    else:
        review_type = "scope"
    detail = title.split("-", 1)[-1].strip() if "-" in title else "全文"
    if node_id.startswith("issuer_basic_"):
        chapters = ["第四节", "发行人基本情况", detail]
    elif node_id.startswith("financials_"):
        chapters = ["第五节", "发行人主要财务情况", detail]
    elif node_id in {"finance_tasks"}:
        chapters = ["第五节", "发行人主要财务情况", "全文"]
    elif node_id.startswith("cross_check_") or node_id in {"scope_check", "low_level_review"}:
        chapters = ["全文"]
    else:
        chapters = [detail]
    fast_ids = {
        "review_statement",
        "review_major_matters",
        "review_risk",
        "review_terms",
        "review_proceeds",
        "review_credit",
        "review_investor_protection",
        "review_default",
        "low_level_review",
        "issuer_basic_01_profile",
        "issuer_basic_03_equity",
        "issuer_basic_07_business",
        "financials_02_statements",
        "financials_03_assets",
        "financials_04_liabilities",
        "financials_05_cashflow",
        "financials_06_solvency",
        "financials_09_guarantees",
        "financials_11_restricted",
        "cross_check_basic",
    }
    modes = (
        ["快速审核", "标准审核", "深度审核"]
        if node_id in fast_ids or node_id == "scope_check"
        else ["标准审核", "深度审核"]
    )
    cross_file = node_id.startswith("cross_check_") or node_id in {
        "financials_01_reports",
        "financials_02_statements",
        "financials_09_guarantees",
        "financials_10_litigation",
        "financials_11_restricted",
        "review_meeting",
        "review_trustee",
    }
    module_aliases = {
        "chapter": [detail],
        "issuer_special": ["发行人专项", "发行人基本情况", "第四节"],
        "financial": ["财务专项", "财务核对", "第五节"],
        "cross_chapter": ["跨章节", "一致性核对"],
        "low_level": ["低级错误", "数据一致性"],
        "scope": ["适用范围"],
    }[review_type]
    return {
        "task_id": node_id,
        "name_zh": title,
        "review_type": review_type,
        "applicable_documents": ["募集说明书"] + (["已上传的配套材料"] if cross_file else []),
        "applicable_chapters": list(dict.fromkeys(chapters)),
        "trigger_conditions": ["文件角色识别成功", "用户模式或专项选择包含本任务"],
        "dependencies": ["scope_check"] if node_id != "scope_check" else [],
        "rule_file": rule_path(node_id, title),
        "requires_full_text_search": review_type in {"low_level", "cross_chapter", "scope"},
        "requires_financial_script": review_type == "financial" or node_id == "cross_check_finance",
        "requires_cross_document_check": cross_file,
        "review_modes": modes,
        "output_group": "低级错误与数据一致性专项核查" if node_id == "low_level_review" else review_type,
        "module_aliases": module_aliases,
        "not_run_reason_codes": [
            "MODE_EXCLUDED",
            "MODULE_NOT_SELECTED",
            "DOCUMENT_NOT_PROVIDED",
            "CHAPTER_NOT_FOUND",
            "INSUFFICIENT_TEXT_LAYER",
        ],
    }


def derived_cross_document_tasks() -> list[dict[str, Any]]:
    documents = [
        ("cross_audit_reports", "募集说明书与多份审计报告核对", "审计报告"),
        ("cross_trustee_agreement", "募集说明书与受托管理协议核对", "受托管理协议"),
        ("cross_holders_rules", "募集说明书与持有人会议规则核对", "债券持有人会议规则"),
        ("cross_legal_opinion", "募集说明书与法律意见书核对", "法律意见书"),
        ("cross_underwriter_opinion", "募集说明书与主承销商核查意见核对", "主承销商核查意见"),
        ("cross_internal_replies", "募集说明书与立项质控内核反馈回复核对", "反馈回复"),
        ("cross_inquiry_checklist", "募集说明书与问核表核对", "问核表"),
        ("cross_rating_report", "募集说明书与评级报告核对", "评级报告"),
        ("cross_other_workpapers", "募集说明书与合同批复章程及其他底稿核对", "其他项目底稿"),
    ]
    return [
        {
            "task_id": task_id,
            "name_zh": name,
            "review_type": "cross_document",
            "applicable_documents": ["募集说明书", document],
            "applicable_chapters": ["全文"],
            "trigger_conditions": ["标准审核或深度审核", f"已上传{document}"],
            "dependencies": ["scope_check"],
            "rule_file": "references/cross-document-rules/external-materials.md",
            "requires_full_text_search": True,
            "requires_financial_script": task_id == "cross_audit_reports",
            "requires_cross_document_check": True,
            "review_modes": ["标准审核", "深度审核"],
            "output_group": "cross_document",
            "module_aliases": ["跨文件", document, name],
            "not_run_reason_codes": [
                "MODE_EXCLUDED",
                "MODULE_NOT_SELECTED",
                "DOCUMENT_NOT_PROVIDED",
                "INSUFFICIENT_TEXT_LAYER",
            ],
        }
        for task_id, name, document in documents
    ]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    args = parser.parse_args()
    source = args.source.resolve()
    raw = yaml.safe_load(source.read_text(encoding="utf-8-sig"))
    graph = raw["workflow"]["graph"]
    nodes = graph.get("nodes", [])
    edges = graph.get("edges", [])
    node_by_id = {str(n["id"]): n for n in nodes}
    incoming: dict[str, list[str]] = defaultdict(list)
    outgoing: dict[str, list[str]] = defaultdict(list)
    for edge in edges:
        incoming[str(edge.get("target"))].append(str(edge.get("source")))
        outgoing[str(edge.get("source"))].append(str(edge.get("target")))

    inventory_nodes = []
    migrations = []
    for index, node in enumerate(nodes, 1):
        target, status, note = mapping_for(node)
        data = copy.deepcopy(node.get("data", {}))
        inventory_nodes.append(
            {
                "ordinal": index,
                "id": str(node["id"]),
                "title": data.get("title", ""),
                "type": data.get("type", "unknown"),
                "config": data,
                "incoming_node_ids": incoming.get(str(node["id"]), []),
                "outgoing_node_ids": outgoing.get(str(node["id"]), []),
                "migration": {"target": target, "status": status, "notes": note},
            }
        )
        migrations.append((node, target, status, note))
        if data.get("type") == "llm":
            write_rule_file(node)

    inventory = {
        "source": {"name": source.name, "size_bytes": source.stat().st_size, "dsl_version": raw.get("version")},
        "app": raw.get("app", {}),
        "workflow": {
            "conversation_variables": raw["workflow"].get("conversation_variables", []),
            "environment_variables": raw["workflow"].get("environment_variables", []),
            "features": raw["workflow"].get("features", {}),
        },
        "counts": {
            "nodes": len(nodes),
            "edges": len(edges),
            "node_types": dict(sorted(Counter(n["data"].get("type", "unknown") for n in nodes).items())),
        },
        "nodes": inventory_nodes,
        "edges": edges,
        "unresolved_edge_node_ids": sorted(
            {x for e in edges for x in (str(e.get("source")), str(e.get("target"))) if x not in node_by_id}
        ),
    }
    build = ROOT / "build"
    docs = ROOT / "docs"
    build.mkdir(exist_ok=True)
    docs.mkdir(exist_ok=True)
    (build / "dify_inventory.json").write_text(json.dumps(inventory, ensure_ascii=False, indent=2), encoding="utf-8")

    type_counts = inventory["counts"]["node_types"]
    lines = [
        "# Dify 工作流完整清单",
        "",
        f"- DSL 版本：`{raw.get('version')}`",
        f"- 节点：**{len(nodes)}**",
        f"- 连线：**{len(edges)}**",
        f"- 开始输入：`{compact(node_by_id['start']['data'].get('variables', []), 1000)}`",
        "",
        "## 节点类型数量",
        "",
        "| 类型 | 数量 |",
        "|---|---:|",
    ]
    lines += [f"| {k} | {v} |" for k, v in type_counts.items()]
    lines += [
        "",
        "## 工作流概貌",
        "",
        "工作流由文件解析、适用范围判断、章节/专项 LLM 审核、财务确定性代码、模式路由、跳过分支、变量聚合、跨章节核对和报告生成构成。42 组 gate/skip/aggregator 三联结构是最显著的重复模式。",
        "",
        "## 输入输出关系",
        "",
        "完整连线和每个节点的入边/出边保存在 `build/dify_inventory.json`。下表保留所有节点的直接依赖。",
        "",
        "## 全部节点清单",
        "",
        "| # | ID | 名称 | 类型 | 输入节点 | 输出节点 | 关键配置摘要 |",
        "|---:|---|---|---|---|---|---|",
    ]
    for item in inventory_nodes:
        cfg = {k: v for k, v in item["config"].items() if k not in {"code", "prompt_template"}}
        lines.append(
            f"| {item['ordinal']} | `{item['id']}` | {item['title']} | `{item['type']}` | {', '.join(item['incoming_node_ids']) or '-'} | {', '.join(item['outgoing_node_ids']) or '-'} | {compact(cfg)} |"
        )
    llm_titles = [n["data"].get("title", n["id"]) for n in nodes if n["data"].get("type") == "llm"]
    lines += [
        "",
        "## 审核模块清单",
        "",
        *[f"- {x}" for x in llm_titles],
        "",
        "## 重复节点模式",
        "",
        "- 42 个 `if-else` gate：统一迁移到配置驱动任务路由器。",
        "- 42 个 `variable-aggregator`：统一迁移到结果收集、去重、排序和报告生成。",
        "- 42 个 `__skip` 代码节点：统一迁移为标准未执行原因代码。",
        "- LLM prompt 中重复的证据、禁止臆测、低误报和 JSON 输出约束：提取为公共 policy references。",
        "",
        "## 高耦合部分",
        "",
        "- `review_router` 与 42 个 gate/skip/aggregator 三联结构。",
        "- 财务抽取、代码重算、附注核对、第五章表格核对与跨章节财务审核。",
        "- 报告生成依赖所有章节、专项、跨章节和跳过结果的统一格式。",
        "- 多份审计报告迭代与审计报告合并上下文。",
        "",
        "## 迁移风险与可能丢失的信息",
        "",
        "- Dify 的可视化执行时序改为 Skill 自主编排，需以配置和测试保证覆盖。",
        "- 原工作流模型提供商和 token/temperature 参数不再逐节点复现；推理由当前 ChatGPT Work/Codex 会话执行。",
        "- 原 document-extractor 的具体版面解析表现无法静态等价；扫描件和复杂表格必须降级为视觉/OCR或人工复核。",
        "- 未经真实项目盲测，不能声称业务效果与原 Dify 完全等价。",
        "- 节点完整原配置、代码、prompt、变量引用及 451 条连线均保存在机器库存，便于后续审计。",
        "",
    ]
    (docs / "dify-workflow-inventory.md").write_text("\n".join(lines), encoding="utf-8")

    map_lines = [
        "# Dify 到 Skill 迁移映射",
        "",
        "| Dify节点ID | Dify节点名称 | 节点类型 | 原功能 | Skill目标文件或函数 | 迁移状态 | 备注 |",
        "|---|---|---|---|---|---|---|",
    ]
    for node, target, status, note in migrations:
        data = node["data"]
        original = compact({k: v for k, v in data.items() if k not in {"code", "prompt_template"}}, 180)
        map_lines.append(
            f"| `{node['id']}` | {data.get('title', '')} | `{data.get('type', '')}` | {original} | {target} | {status} | {note} |"
        )
    (docs / "migration-map.md").write_text("\n".join(map_lines) + "\n", encoding="utf-8")

    tasks = [task_from_llm(n) for n in nodes if n["data"].get("type") == "llm"] + derived_cross_document_tasks()
    config_dir = SKILL / "config"
    config_dir.mkdir(exist_ok=True)
    (config_dir / "review_tasks.yaml").write_text(
        yaml.safe_dump({"tasks": tasks}, allow_unicode=True, sort_keys=False), encoding="utf-8"
    )
    print(json.dumps(inventory["counts"], ensure_ascii=False))
    print(f"wrote {len(tasks)} configured tasks and {len(migrations)} migration rows")


if __name__ == "__main__":
    main()
