#!/usr/bin/env python3
from __future__ import annotations

import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SKILL = ROOT / "company-bond-prospectus-review"
OUTPUT = ROOT / "dist" / "company-bond-prospectus-review.zip"
BLOCKED_SUFFIXES = {".yml", ".log", ".pyc"}
BLOCKED_PARTS = {"__pycache__", ".pytest_cache", ".git", "tests", "build", "dist"}


def package() -> Path:
    OUTPUT.parent.mkdir(exist_ok=True)
    files = []
    for path in SKILL.rglob("*"):
        if not path.is_file() or any(part in BLOCKED_PARTS for part in path.parts):
            continue
        if path.suffix.lower() in BLOCKED_SUFFIXES and path.name != "openai.yaml":
            continue
        files.append(path)
    with zipfile.ZipFile(OUTPUT, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for path in sorted(files):
            zf.write(path, Path(SKILL.name) / path.relative_to(SKILL))
    return OUTPUT


if __name__ == "__main__":
    print(package())
