from decimal import Decimal

from calculate_financial_metrics import calculate_metrics, check_equation, compare_reported_metric, safe_ratio
from common import convert_unit, decimal_value, normalize_reporting_period
from reconcile_financial_data import reconcile_pair


def test_decimal_and_units() -> None:
    assert decimal_value("1,234.50") == Decimal("1234.50")
    assert decimal_value("(12.5)") == Decimal("-12.5")
    assert decimal_value("（12.5）") == Decimal("-12.5")
    assert convert_unit("1.2", "亿元", "万元") == Decimal("12000.0")
    assert convert_unit("10", "千元", "万元") == Decimal("1")


def test_equation_thresholds() -> None:
    assert check_equation("100", ["60", "40"])["status"] == "match"
    assert check_equation("100", ["99.995"], "0.01")["status"] == "rounding_difference"
    assert check_equation("100", ["99"], "0.01")["status"] == "error"


def test_ratios_and_zero_denominator() -> None:
    assert safe_ratio("50", "200")["value"] == "25.00"
    assert safe_ratio("1", "0")["status"] == "insufficient_data"
    metrics = calculate_metrics(
        {
            "total_assets": "200",
            "total_liabilities": "80",
            "current_assets": "60",
            "current_liabilities": "30",
            "inventory": "10",
        }
    )
    assert metrics["asset_liability_ratio_pct"]["value"] == "40.0"
    assert metrics["current_ratio"]["value"] == "2"


def test_reconcile_units_and_ocr_conflict() -> None:
    left = {"value": "1", "unit": "亿元", "document": "募集说明书", "location": "P1"}
    right = {"value": "10000", "unit": "万元", "document": "审计报告", "location": "P2"}
    assert reconcile_pair(left, right)["status"] == "match"
    right["ocr_conflict"] = True
    result = reconcile_pair(left, right)
    assert result["status"] == "ocr_conflict" and result["manual_review_required"]


def test_reported_asset_liability_ratio_error_and_period_normalization() -> None:
    calculated = calculate_metrics({"total_assets": "200", "total_liabilities": "80"})["asset_liability_ratio_pct"][
        "value"
    ]
    assert compare_reported_metric("45", calculated)["status"] == "error"
    assert normalize_reporting_period("2025年12月31日") == "2025-12-31"


def test_extended_source_workflow_metrics_are_deterministic() -> None:
    metrics = calculate_metrics(
        {
            "non_current_assets": "80",
            "total_assets": "200",
            "short_term_interest_bearing_debt": "30",
            "interest_bearing_debt": "100",
            "operating_cash_inflow": "50",
            "ebitda": "24",
            "interest_expense": "6",
            "credit_line_total": "100",
            "credit_line_used": "65",
        }
    )
    assert metrics["non_current_asset_ratio_pct"]["value"] == "40.0"
    assert metrics["short_term_interest_bearing_debt_ratio_pct"]["value"] == "30.0"
    assert metrics["operating_cash_inflow_debt_coverage"]["value"] == "0.5"
    assert metrics["ebitda_interest_coverage"]["value"] == "4"
    assert metrics["credit_line_unused"]["value"] == "35"
