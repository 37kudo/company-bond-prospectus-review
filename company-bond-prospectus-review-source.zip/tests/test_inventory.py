from __future__ import annotations

import json
from pathlib import Path

import yaml
from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[1]
SKILL = ROOT / "company-bond-prospectus-review"


def test_inventory_counts_and_complete_mapping() -> None:
    inventory = json.loads((ROOT / "build" / "dify_inventory.json").read_text(encoding="utf-8"))
    assert inventory["counts"]["nodes"] == 199
    assert inventory["counts"]["edges"] == 451
    assert inventory["counts"]["node_types"] == {
        "code": 64,
        "document-extractor": 4,
        "end": 1,
        "if-else": 42,
        "iteration": 1,
        "iteration-start": 1,
        "llm": 43,
        "start": 1,
        "variable-aggregator": 42,
    }
    assert len(inventory["nodes"]) == 199
    assert not inventory["unresolved_edge_node_ids"]
    assert all(n["migration"]["target"] and n["migration"]["status"] for n in inventory["nodes"])


def test_every_llm_has_task_and_rule_file() -> None:
    inventory = json.loads((ROOT / "build" / "dify_inventory.json").read_text(encoding="utf-8"))
    tasks = yaml.safe_load((SKILL / "config" / "review_tasks.yaml").read_text(encoding="utf-8"))["tasks"]
    llm_ids = {n["id"] for n in inventory["nodes"] if n["type"] == "llm"}
    assert llm_ids <= {t["task_id"] for t in tasks}
    assert len(tasks) == 52
    assert all((SKILL / t["rule_file"]).is_file() for t in tasks)


def test_schema_files_parse() -> None:
    for path in (SKILL / "schemas").glob("*.json"):
        schema = json.loads(path.read_text(encoding="utf-8"))
        assert schema["$schema"]
        Draft202012Validator.check_schema(schema)
