from pathlib import Path

from route_tasks import load_tasks, route_tasks
from validate_issues import validate_issue

ROOT = Path(__file__).resolve().parents[1]
CONFIG = ROOT / "company-bond-prospectus-review" / "config" / "review_tasks.yaml"


def valid_issue() -> dict:
    return {
        "issue_id": "x",
        "category": "跨章节不一致",
        "severity": "中",
        "document": "募集说明书",
        "chapter": "第二节",
        "location": "P10",
        "source_excerpt": "发行规模10亿元",
        "issue_description": "与第三节不一致",
        "comparison_evidence": "第三节载明9亿元",
        "calculation": "",
        "suggested_revision": "统一为经核实的金额",
        "confidence": 0.9,
        "manual_review_required": False,
        "related_task_ids": ["cross_check_terms"],
    }


def cross_file_issue() -> dict:
    value = valid_issue()
    value.update(
        {
            "category": "跨文件不一致",
            "document": "募集说明书 / 受托管理协议",
            "comparison_evidence": {
                "left": {"document": "募集说明书", "location": "第十三节", "excerpt": "提交甲地法院"},
                "right": {"document": "受托管理协议", "location": "第20条", "excerpt": "提交乙地仲裁委"},
                "difference": "争议解决机构不同",
            },
        }
    )
    return value


def test_quick_and_selected_module_keep_mandatory_tasks() -> None:
    tasks = load_tasks(CONFIG)
    routed = {
        x["task_id"]: x for x in route_tasks(tasks, "快速审核", ["review_proceeds"], available_documents=["募集说明书"])
    }
    assert routed["scope_check"]["run"]
    assert routed["low_level_review"]["run"]
    assert routed["review_proceeds"]["run"]
    assert not routed["review_tax"]["run"]


def test_quick_mode_matches_source_router_and_excludes_finance_prework() -> None:
    tasks = load_tasks(CONFIG)
    running = {x["task_id"] for x in route_tasks(tasks, "快速审核") if x["run"]}
    assert "review_statement" in running
    assert "review_risk" in running
    assert "financials_03_assets" in running
    assert "financials_05_cashflow" in running
    assert "finance_tasks" not in running


def test_fourth_and_fifth_section_selection_routes_subtasks() -> None:
    tasks = load_tasks(CONFIG)
    fourth = {x["task_id"]: x for x in route_tasks(tasks, "标准审核", selected_chapters=["第四节"])}
    fifth = {x["task_id"]: x for x in route_tasks(tasks, "标准审核", selected_chapters=["第五节"])}
    assert fourth["issuer_basic_08_projects"]["run"]
    assert not fourth["financials_03_assets"]["run"]
    assert fifth["financials_03_assets"]["run"]
    assert not fifth["issuer_basic_08_projects"]["run"]


def test_missing_optional_document_does_not_create_issue() -> None:
    tasks = load_tasks(CONFIG)
    routed = route_tasks(tasks, "深度审核", available_documents=["募集说明书"])
    assert any((not x["run"] and x["reason_code"] == "DOCUMENT_NOT_PROVIDED") for x in routed)


def test_issue_validation() -> None:
    issue = valid_issue()
    assert validate_issue(issue) == []
    issue["category"] = "跨文件不一致"
    issue["comparison_evidence"] = "募集说明书与协议不一致"
    assert "evidence:two_sided_comparison_required" in validate_issue(issue)
    issue = cross_file_issue()
    assert validate_issue(issue, {"募集说明书", "受托管理协议"}) == []
    assert "document:not_uploaded" in validate_issue(issue, {"募集说明书"})
