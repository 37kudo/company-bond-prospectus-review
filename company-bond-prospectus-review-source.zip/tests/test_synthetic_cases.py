from build_report import LOW_LEVEL_SECTION, build_markdown, build_report_data
from compare_financial_records import compare_records
from compare_trustee_clauses import compare_clauses
from deduplicate_issues import deduplicate
from extract_core_fields import detect_period_phrase_conflict, extract_fields
from reconcile_financial_data import reconcile_pair
from route_tasks import route_tasks


def issue(task: str, severity: str = "中") -> dict:
    return {
        "issue_id": "",
        "category": "低级错误",
        "severity": severity,
        "document": "募集说明书",
        "chapter": "封面",
        "location": "封面",
        "source_excerpt": "甲公司",
        "issue_description": "残留其他发行人名称",
        "comparison_evidence": "",
        "calculation": "",
        "suggested_revision": "替换为当前发行人名称",
        "confidence": 0.9,
        "manual_review_required": False,
        "related_task_ids": [task],
    }


def test_core_field_conflicts_cover_scale_and_issuer() -> None:
    text = "发行人：甲公司\n本期发行规模：10亿元\n募集资金总额：9亿元\n发行人：乙公司\n本期发行规模：9亿元"
    fields = extract_fields(text)
    assert fields["issuer_name"]["status"] == "conflict"
    assert fields["issue_amount"]["status"] == "conflict"
    assert fields["proceeds_amount"]["values"] == ["9亿元"]


def test_duplicate_findings_merge_tasks_and_severity() -> None:
    merged = deduplicate([issue("low_level_review", "低"), issue("cross_check_basic", "高")])
    assert len(merged) == 1
    assert merged[0]["severity"] == "高"
    assert merged[0]["related_task_ids"] == ["cross_check_basic", "low_level_review"]


def test_low_level_section_present_even_empty() -> None:
    report = build_markdown([])
    assert f"## {LOW_LEVEL_SECTION}" in report
    assert "本次未识别到明确问题" in report
    data = build_report_data([], "标准审核")
    assert data["summary"]["low_level_section_present"] is True
    assert set(data) == {"mode", "summary", "issues", "task_status", "limitations"}


def test_reporting_period_phrase_mix_detected() -> None:
    result = detect_period_phrase_conflict("本节披露近三年及一期数据，附表注明近两年及一期。")
    assert result["status"] == "conflict"


def test_guarantee_text_table_mismatch() -> None:
    text = {"value": "1.5", "unit": "亿元", "document": "募集说明书正文", "location": "第五节"}
    table = {"value": "12000", "unit": "万元", "document": "募集说明书表格", "location": "担保表"}
    assert reconcile_pair(text, table)["status"] == "error"


def test_missing_trustee_agreement_is_skip_not_issue() -> None:
    tasks = [
        {
            "task_id": "cross_trustee_agreement",
            "review_modes": ["深度审核"],
            "applicable_documents": ["募集说明书", "受托管理协议"],
            "applicable_chapters": ["全文"],
            "requires_full_text_search": True,
        }
    ]
    routed = route_tasks(tasks, "深度审核", available_documents=["募集说明书"])
    assert routed == [{"task_id": "cross_trustee_agreement", "run": False, "reason_code": "DOCUMENT_NOT_PROVIDED"}]


def test_trustee_clause_comparison_has_two_sided_evidence() -> None:
    result = compare_clauses("争议提交发行人所在地人民法院诉讼", "争议提交乙方所在地仲裁委员会仲裁")
    assert result["status"] == "mismatch"
    evidence = result["comparison_evidence"]
    assert evidence["left"]["document"] == "募集说明书"
    assert evidence["right"]["document"] == "受托管理协议"


def test_financial_record_comparison_preserves_period_scope_and_evidence() -> None:
    left = [
        {
            "item": "资产合计",
            "period": "2025年末",
            "scope": "合并",
            "value": "1",
            "unit": "亿元",
            "document": "募集说明书",
            "location": "第五节表1",
        }
    ]
    right = [
        {
            "item": "资产总计",
            "period": "2025年末",
            "scope": "合并",
            "value": "9990",
            "unit": "万元",
            "document": "审计报告",
            "location": "资产负债表",
        }
    ]
    result = compare_records(left, right)
    assert result["status"] == "mismatch"
    assert result["mismatches"][0]["left_evidence"]["document"] == "募集说明书"
    assert result["mismatches"][0]["right_evidence"]["document"] == "审计报告"
