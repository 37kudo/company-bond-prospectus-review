import zipfile
from pathlib import Path

import pytest
from inspect_inputs import resolve_child

from tools.package_skill import package

ROOT = Path(__file__).resolve().parents[1]


def test_path_traversal_rejected(tmp_path: Path) -> None:
    with pytest.raises(ValueError):
        resolve_child(tmp_path, "../secret.txt")


def test_zip_excludes_source_and_dev_artifacts() -> None:
    output = package()
    with zipfile.ZipFile(output) as zf:
        names = zf.namelist()
    assert names
    assert not any(name.lower().endswith(".yml") for name in names)
    assert not any("test" in Path(name).parts or "__pycache__" in name or name.endswith(".log") for name in names)
    assert "company-bond-prospectus-review/SKILL.md" in names


def test_scripts_do_not_call_external_models_or_mineru() -> None:
    scripts = ROOT / "company-bond-prospectus-review" / "scripts"
    text = "\n".join(path.read_text(encoding="utf-8").lower() for path in scripts.glob("*.py"))
    assert "api.openai.com" not in text
    assert "mineru" not in text
    assert "requests.post" not in text
