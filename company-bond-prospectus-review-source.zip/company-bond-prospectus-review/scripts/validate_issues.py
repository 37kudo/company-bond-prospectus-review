#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from typing import Any

REQUIRED = {
    "issue_id",
    "category",
    "severity",
    "document",
    "chapter",
    "location",
    "source_excerpt",
    "issue_description",
    "comparison_evidence",
    "calculation",
    "suggested_revision",
    "confidence",
    "manual_review_required",
    "related_task_ids",
}
SEVERITIES = {"高", "中", "低", "提示"}


def _valid_side(value: Any) -> bool:
    return isinstance(value, dict) and all(
        str(value.get(key, "")).strip() for key in ("document", "location", "excerpt")
    )


def _cross_file_documents(comparison: Any) -> set[str]:
    if not isinstance(comparison, dict):
        return set()
    return {
        str(side.get("document", "")).strip()
        for side in (comparison.get("left"), comparison.get("right"))
        if isinstance(side, dict) and str(side.get("document", "")).strip()
    }


def validate_issue(issue: dict[str, Any], uploaded_documents: set[str] | None = None) -> list[str]:
    errors = [f"missing:{key}" for key in sorted(REQUIRED - issue.keys())]
    if issue.get("severity") not in SEVERITIES:
        errors.append("invalid:severity")
    if not str(issue.get("source_excerpt", "")).strip() and not issue.get("manual_review_required"):
        errors.append("evidence:source_excerpt_required")
    if not str(issue.get("document", "")).strip() or not str(issue.get("location", "")).strip():
        errors.append("evidence:document_and_location_required")
    comparison = issue.get("comparison_evidence")
    if issue.get("category") == "跨文件不一致":
        if (
            not isinstance(comparison, dict)
            or not _valid_side(comparison.get("left"))
            or not _valid_side(comparison.get("right"))
        ):
            errors.append("evidence:two_sided_comparison_required")
        elif comparison["left"]["document"] == comparison["right"]["document"]:
            errors.append("evidence:two_distinct_documents_required")
    if issue.get("category") == "财务计算错误" and not str(issue.get("calculation", "")).strip():
        errors.append("calculation:reproducible_formula_required")
    if uploaded_documents is not None and issue.get("category") == "跨文件不一致":
        cited = _cross_file_documents(comparison)
        if cited and not cited <= uploaded_documents:
            errors.append("document:not_uploaded")
    confidence = issue.get("confidence")
    try:
        if confidence is not None and not 0 <= float(confidence) <= 1:
            errors.append("invalid:confidence")
    except (TypeError, ValueError):
        errors.append("invalid:confidence")
    return errors


def validate_issues(issues: list[dict[str, Any]], uploaded_documents: set[str] | None = None) -> dict[str, Any]:
    results = [{"issue_id": i.get("issue_id"), "errors": validate_issue(i, uploaded_documents)} for i in issues]
    return {"valid": all(not x["errors"] for x in results), "results": results}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("json_file")
    args = parser.parse_args()
    issues = json.loads(open(args.json_file, encoding="utf-8").read())
    print(json.dumps(validate_issues(issues), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
