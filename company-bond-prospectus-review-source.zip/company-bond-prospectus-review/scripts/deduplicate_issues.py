#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import re
from typing import Any

from common import SEVERITY_ORDER


def fingerprint(issue: dict[str, Any]) -> str:
    text = "|".join(str(issue.get(k, "")) for k in ("category", "document", "chapter", "location", "issue_description"))
    normalized = re.sub(r"\s+", "", text).lower()
    return hashlib.sha256(normalized.encode("utf-8")).hexdigest()[:20]


def deduplicate(issues: list[dict[str, Any]]) -> list[dict[str, Any]]:
    merged: dict[str, dict[str, Any]] = {}
    for issue in issues:
        key = fingerprint(issue)
        if key not in merged:
            item = dict(issue)
            item.setdefault("issue_id", key)
            item["related_task_ids"] = sorted(set(item.get("related_task_ids", [])))
            merged[key] = item
            continue
        current = merged[key]
        current["related_task_ids"] = sorted(
            set(current.get("related_task_ids", [])) | set(issue.get("related_task_ids", []))
        )
        if SEVERITY_ORDER.get(issue.get("severity"), 9) < SEVERITY_ORDER.get(current.get("severity"), 9):
            current["severity"] = issue["severity"]
        current["confidence"] = max(float(current.get("confidence", 0)), float(issue.get("confidence", 0)))
        current["manual_review_required"] = bool(
            current.get("manual_review_required") or issue.get("manual_review_required")
        )
    return sorted(
        merged.values(),
        key=lambda x: (SEVERITY_ORDER.get(x.get("severity"), 9), x.get("document", ""), x.get("location", "")),
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("json_file")
    args = parser.parse_args()
    issues = json.loads(open(args.json_file, encoding="utf-8").read())
    print(json.dumps(deduplicate(issues), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
