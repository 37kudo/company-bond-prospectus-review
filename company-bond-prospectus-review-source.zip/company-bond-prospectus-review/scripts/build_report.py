#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from collections import Counter, defaultdict
from typing import Any

LOW_LEVEL_SECTION = "低级错误与数据一致性专项核查"


def _escape_table(value: Any) -> str:
    return str(value or "").replace("|", "\\|").replace("\n", " ")


def build_report_data(
    issues: list[dict[str, Any]],
    mode: str,
    task_status: list[dict[str, Any]] | None = None,
    limitations: list[str] | None = None,
) -> dict[str, Any]:
    counts = Counter(i.get("severity", "未知") for i in issues)
    return {
        "mode": mode,
        "summary": {
            "total": len(issues),
            "by_severity": {level: counts[level] for level in ("高", "中", "低", "提示")},
            "low_level_section_present": True,
        },
        "issues": issues,
        "task_status": task_status or [],
        "limitations": limitations or ["仅基于已上传且成功读取的材料"],
    }


def build_markdown(issues: list[dict[str, Any]], task_status: list[dict[str, Any]] | None = None) -> str:
    counts = Counter(i.get("severity", "未知") for i in issues)
    lines = [
        "# 公司债募集说明书智能审核报告",
        "",
        "## 审核摘要",
        "",
        f"共识别 {len(issues)} 项问题；高 {counts['高']}、中 {counts['中']}、低 {counts['低']}、提示 {counts['提示']}。",
        "",
    ]
    groups: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for issue in issues:
        group = LOW_LEVEL_SECTION if issue.get("category") == "低级错误" else issue.get("chapter") or "其他专项"
        groups[group].append(issue)
    groups.setdefault(LOW_LEVEL_SECTION, [])
    for group, items in groups.items():
        lines += [f"## {group}", ""]
        if not items:
            lines += ["本次未识别到明确问题。", ""]
            continue
        lines += ["| 等级 | 类别 | 文件与位置 | 问题 | 证据 | 修改建议 |", "|---|---|---|---|---|---|"]
        for i in items:
            comparison = i.get("comparison_evidence")
            if isinstance(comparison, dict):
                evidence_parts = []
                for side_name in ("left", "right"):
                    side = comparison.get(side_name) or {}
                    evidence_parts.append(
                        f"{side.get('document', '')} {side.get('location', '')}: {side.get('excerpt', '')}"
                    )
                comparison = "；".join(evidence_parts)
            lines.append(
                f"| {_escape_table(i.get('severity'))} | {_escape_table(i.get('category'))} | {_escape_table(i.get('document'))} {_escape_table(i.get('location'))} | {_escape_table(i.get('issue_description'))} | {_escape_table(i.get('source_excerpt'))} {_escape_table(comparison)} | {_escape_table(i.get('suggested_revision'))} |"
            )
        lines.append("")
    if task_status:
        lines += ["## 任务执行状态", "", "| 任务 | 状态 | 未执行原因 |", "|---|---|---|"]
        for item in task_status:
            lines.append(
                f"| {item['task_id']} | {'已执行' if item.get('run') else '未执行'} | {item.get('reason_code') or '-'} |"
            )
        lines.append("")
    lines += [
        "## 重要说明",
        "",
        "本报告仅基于已提供且可读取的材料。未上传的外部文件不据此认定为披露缺失；证据不足、扫描质量不足或 OCR 冲突的事项已标记人工复核。",
        "",
    ]
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("issues_json")
    parser.add_argument("--format", choices=["Markdown", "JSON", "Word大纲"], default="Markdown")
    parser.add_argument("--mode", choices=["快速审核", "标准审核", "深度审核"], default="标准审核")
    parser.add_argument("--task-status-json")
    parser.add_argument("--limitations-json")
    args = parser.parse_args()
    issues = json.loads(open(args.issues_json, encoding="utf-8").read())
    task_status = json.loads(open(args.task_status_json, encoding="utf-8").read()) if args.task_status_json else []
    limitations = json.loads(open(args.limitations_json, encoding="utf-8").read()) if args.limitations_json else []
    if args.format == "JSON":
        print(json.dumps(build_report_data(issues, args.mode, task_status, limitations), ensure_ascii=False, indent=2))
    else:
        print(build_markdown(issues, task_status))


if __name__ == "__main__":
    main()
