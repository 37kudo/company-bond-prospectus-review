#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
from typing import Any

from reconcile_financial_data import reconcile_pair

ALIASES = {
    "资产合计": "资产总计",
    "负债总额": "负债合计",
    "营业总收入": "营业收入",
    "股东权益合计": "所有者权益合计",
    "投资性房产": "投资性房地产",
}


def normalize_item(value: str) -> str:
    text = re.sub(r"[\s:：_\-]", "", str(value or ""))
    for raw, canonical in ALIASES.items():
        text = text.replace(raw, canonical)
    return text


def _key(record: dict[str, Any]) -> tuple[str, str, str]:
    period = re.sub(r"\s+", "", str(record.get("period", "")))
    scope = str(record.get("scope", "合并"))
    return normalize_item(str(record.get("item", ""))), period, scope


def compare_records(
    left_records: list[dict[str, Any]],
    right_records: list[dict[str, Any]],
    tolerance: Any = "0.01",
) -> dict[str, Any]:
    right_index: dict[tuple[str, str, str], list[dict[str, Any]]] = {}
    for record in right_records:
        right_index.setdefault(_key(record), []).append(record)
    compared, mismatches, unmatched = [], [], []
    for left in left_records:
        candidates = right_index.get(_key(left), [])
        if len(candidates) != 1:
            unmatched.append({"left": left, "candidate_count": len(candidates)})
            continue
        result = reconcile_pair(left, candidates[0], tolerance)
        item = {"item": left.get("item"), "period": left.get("period"), "scope": left.get("scope", "合并"), **result}
        compared.append(item)
        if result.get("status") in {"error", "ocr_conflict"}:
            mismatches.append(item)
    return {
        "status": "mismatch" if mismatches else "match" if compared else "insufficient_data",
        "compared_count": len(compared),
        "mismatch_count": len(mismatches),
        "mismatches": mismatches,
        "unmatched": unmatched,
        "manual_review_required": bool(unmatched) or any(x.get("manual_review_required") for x in mismatches),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("left_json")
    parser.add_argument("right_json")
    parser.add_argument("--tolerance", default="0.01")
    args = parser.parse_args()
    print(
        json.dumps(
            compare_records(json.loads(args.left_json), json.loads(args.right_json), args.tolerance),
            ensure_ascii=False,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
