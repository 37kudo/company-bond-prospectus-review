#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from decimal import Decimal
from typing import Any

from common import convert_unit, decimal_value


def check_equation(left: Any, right_parts: list[Any], tolerance: Any = "0.01") -> dict[str, Any]:
    left_d = decimal_value(left)
    right_d = sum((decimal_value(v) for v in right_parts), Decimal("0"))
    diff = left_d - right_d
    tol = abs(decimal_value(tolerance))
    status = "match" if diff == 0 else "rounding_difference" if abs(diff) <= tol else "error"
    return {
        "status": status,
        "left": str(left_d),
        "right": str(right_d),
        "difference": str(diff),
        "tolerance": str(tol),
    }


def safe_ratio(numerator: Any, denominator: Any, scale: Any = "100") -> dict[str, Any]:
    n, d = decimal_value(numerator), decimal_value(denominator)
    if d == 0:
        return {"status": "insufficient_data", "value": None, "reason": "denominator_is_zero"}
    value = n / d * decimal_value(scale)
    return {"status": "calculated", "value": str(value), "formula": f"{n}/{d}*{scale}"}


def calculate_metrics(data: dict[str, Any]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    if {"total_assets", "total_liabilities"} <= data.keys():
        out["asset_liability_ratio_pct"] = safe_ratio(data["total_liabilities"], data["total_assets"])
    if {"current_assets", "current_liabilities"} <= data.keys():
        out["current_ratio"] = safe_ratio(data["current_assets"], data["current_liabilities"], "1")
    if {"current_assets", "inventory", "current_liabilities"} <= data.keys():
        out["quick_ratio"] = safe_ratio(
            decimal_value(data["current_assets"]) - decimal_value(data["inventory"]), data["current_liabilities"], "1"
        )
    if {"revenue", "cost"} <= data.keys():
        out["gross_margin_pct"] = safe_ratio(
            decimal_value(data["revenue"]) - decimal_value(data["cost"]), data["revenue"]
        )
    if {"net_profit", "revenue"} <= data.keys():
        out["net_margin_pct"] = safe_ratio(data["net_profit"], data["revenue"])
    if {"period_expenses", "revenue"} <= data.keys():
        out["period_expense_ratio_pct"] = safe_ratio(data["period_expenses"], data["revenue"])
    if {"non_current_assets", "total_assets"} <= data.keys():
        out["non_current_asset_ratio_pct"] = safe_ratio(data["non_current_assets"], data["total_assets"])
    if {"short_term_interest_bearing_debt", "interest_bearing_debt"} <= data.keys():
        out["short_term_interest_bearing_debt_ratio_pct"] = safe_ratio(
            data["short_term_interest_bearing_debt"], data["interest_bearing_debt"]
        )
    if {"operating_cash_inflow", "interest_bearing_debt"} <= data.keys():
        out["operating_cash_inflow_debt_coverage"] = safe_ratio(
            data["operating_cash_inflow"], data["interest_bearing_debt"], "1"
        )
    if {"ebitda", "interest_expense"} <= data.keys():
        out["ebitda_interest_coverage"] = safe_ratio(data["ebitda"], data["interest_expense"], "1")
    if {"operating_cash_flow_net", "current_liabilities"} <= data.keys():
        out["operating_cash_flow_current_liabilities"] = safe_ratio(
            data["operating_cash_flow_net"], data["current_liabilities"], "1"
        )
    if {"operating_cash_flow_net", "total_liabilities"} <= data.keys():
        out["operating_cash_flow_total_liabilities"] = safe_ratio(
            data["operating_cash_flow_net"], data["total_liabilities"], "1"
        )
    if {"revenue", "average_accounts_receivable"} <= data.keys():
        out["accounts_receivable_turnover"] = safe_ratio(data["revenue"], data["average_accounts_receivable"], "1")
    if {"cost", "average_inventory"} <= data.keys():
        out["inventory_turnover"] = safe_ratio(data["cost"], data["average_inventory"], "1")
    if {"revenue", "average_total_assets"} <= data.keys():
        out["total_asset_turnover"] = safe_ratio(data["revenue"], data["average_total_assets"], "1")
    if {"loan_repaid", "loan_due"} <= data.keys():
        out["loan_repayment_rate_pct"] = safe_ratio(data["loan_repaid"], data["loan_due"])
    if {"interest_paid", "interest_due"} <= data.keys():
        out["interest_payment_rate_pct"] = safe_ratio(data["interest_paid"], data["interest_due"])
    if {"credit_line_total", "credit_line_used"} <= data.keys():
        total = decimal_value(data["credit_line_total"])
        used = decimal_value(data["credit_line_used"])
        out["credit_line_used_ratio_pct"] = safe_ratio(used, total)
        out["credit_line_unused"] = {
            "status": "calculated",
            "value": str(total - used),
            "formula": f"{total}-{used}",
        }
    if {"ending", "beginning"} <= data.keys():
        out["period_change_pct"] = safe_ratio(
            decimal_value(data["ending"]) - decimal_value(data["beginning"]), data["beginning"]
        )
    if {"current", "prior"} <= data.keys():
        out["year_on_year_pct"] = safe_ratio(
            decimal_value(data["current"]) - decimal_value(data["prior"]), data["prior"]
        )
    return out


def compare_reported_metric(reported: Any, calculated: Any, tolerance: Any = "0.01") -> dict[str, Any]:
    return check_equation(reported, [calculated], tolerance)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_json")
    args = parser.parse_args()
    data = json.loads(args.input_json)
    if "convert" in data:
        item = data["convert"]
        print(json.dumps({"value": str(convert_unit(item["value"], item["from"], item["to"]))}, ensure_ascii=False))
    else:
        print(json.dumps(calculate_metrics(data), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
