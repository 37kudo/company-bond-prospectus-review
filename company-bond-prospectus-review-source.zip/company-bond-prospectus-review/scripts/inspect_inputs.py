#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Any

ROLE_PATTERNS = [
    ("募集说明书", r"募集说明书|发行条款|募集资金运用"),
    ("审计报告", r"审计报告|审计意见|会计师事务所"),
    ("财务报表及附注", r"资产负债表|利润表|现金流量表|财务报表附注"),
    ("法律意见书", r"法律意见书|律师事务所"),
    ("主承销商核查意见", r"核查意见|主承销商"),
    ("受托管理协议", r"受托管理协议|受托管理人职责"),
    ("债券持有人会议规则", r"持有人会议规则|债券持有人会议"),
    ("评级报告", r"信用评级报告|评级展望|评级机构"),
    ("问核表", r"问核表|问核事项"),
    ("反馈回复", r"立项回复|质控回复|内核回复|反馈回复"),
    ("章程", r"公司章程"),
    ("批复", r"批复|注册通知书|同意注册"),
    ("合同", r"合同|协议"),
]


def classify_role(filename: str, text_sample: str = "") -> dict[str, Any]:
    evidence = f"{filename}\n{text_sample[:12000]}"
    scores = [(role, len(re.findall(pattern, evidence, flags=re.I))) for role, pattern in ROLE_PATTERNS]
    role, score = max(scores, key=lambda x: x[1])
    return {
        "role": role if score else "其他项目底稿",
        "confidence": min(1.0, 0.45 + score * 0.12) if score else 0.2,
        "matched_count": score,
    }


def inspect_file(path: str | Path, text_sample: str = "") -> dict[str, Any]:
    p = Path(path).expanduser().resolve()
    if not p.exists() or not p.is_file():
        raise FileNotFoundError(f"输入文件不存在：{p}")
    role = classify_role(p.name, text_sample)
    suffix = p.suffix.lower()
    has_text = bool(text_sample.strip())
    needs_visual = suffix in {".png", ".jpg", ".jpeg"} or (suffix == ".pdf" and not has_text)
    return {
        "path": str(p),
        "name": p.name,
        "suffix": suffix,
        **role,
        "has_text_layer": has_text,
        "needs_visual_or_ocr": needs_visual,
        "manual_review_required": needs_visual,
    }


def resolve_child(base: str | Path, candidate: str | Path) -> Path:
    root = Path(base).resolve()
    target = (root / candidate).resolve()
    if root != target and root not in target.parents:
        raise ValueError("检测到路径穿越")
    return target


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("path")
    parser.add_argument("--text-sample", default="")
    args = parser.parse_args()
    print(json.dumps(inspect_file(args.path, args.text_sample), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
