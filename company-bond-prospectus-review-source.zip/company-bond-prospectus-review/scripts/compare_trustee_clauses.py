#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
from typing import Any

KEYWORDS = ("争议解决", "纠纷解决", "管辖", "人民法院", "仲裁", "仲裁委员会", "诉讼")
VENUE_PATTERNS = (
    ("发行人所在地", r"(?:发行人|甲方)所在地"),
    ("受托管理人所在地", r"(?:受托管理人|乙方)所在地"),
    ("合同签订地", r"(?:合同|协议)签订地"),
)


def _extract(text: str, document: str, location: str) -> dict[str, Any]:
    normalized = re.sub(r"\s+", "", text or "")
    method = (
        "仲裁"
        if "仲裁" in normalized
        else "诉讼"
        if any(x in normalized for x in ("法院", "诉讼", "管辖"))
        else "未识别"
    )
    venues = [name for name, pattern in VENUE_PATTERNS if re.search(pattern, normalized)]
    institutions = re.findall(r"([\u4e00-\u9fff]{2,30}(?:仲裁委员会|人民法院))", normalized)
    hit = min((normalized.find(k) for k in KEYWORDS if k in normalized), default=0)
    excerpt = normalized[max(0, hit - 80) : hit + 240]
    return {
        "document": document,
        "location": location,
        "excerpt": excerpt,
        "method": method,
        "venues": venues,
        "institutions": list(dict.fromkeys(institutions)),
    }


def compare_clauses(
    prospectus_text: str,
    agreement_text: str,
    prospectus_location: str = "第十三节",
    agreement_location: str = "争议解决条款",
) -> dict[str, Any]:
    left = _extract(prospectus_text, "募集说明书", prospectus_location)
    right = _extract(agreement_text, "受托管理协议", agreement_location)
    if not left["excerpt"] or not right["excerpt"] or "未识别" in {left["method"], right["method"]}:
        return {"status": "insufficient_data", "manual_review_required": True, "left": left, "right": right}
    differences = []
    if left["method"] != right["method"]:
        differences.append(f"争议解决方式不同：{left['method']} / {right['method']}")
    if left["venues"] and right["venues"] and set(left["venues"]) != set(right["venues"]):
        differences.append(f"连接点不同：{left['venues']} / {right['venues']}")
    if left["institutions"] and right["institutions"] and set(left["institutions"]) != set(right["institutions"]):
        differences.append(f"机构不同：{left['institutions']} / {right['institutions']}")
    left_evidence = {key: left[key] for key in ("document", "location", "excerpt")}
    right_evidence = {key: right[key] for key in ("document", "location", "excerpt")}
    return {
        "status": "mismatch" if differences else "match",
        "manual_review_required": False,
        "comparison_evidence": {
            "left": left_evidence,
            "right": right_evidence,
            "difference": "；".join(differences) or "未识别到明确差异",
        },
        "normalized": {"left": left, "right": right},
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("prospectus_text_file")
    parser.add_argument("agreement_text_file")
    args = parser.parse_args()
    with open(args.prospectus_text_file, encoding="utf-8") as f:
        prospectus = f.read()
    with open(args.agreement_text_file, encoding="utf-8") as f:
        agreement = f.read()
    print(json.dumps(compare_clauses(prospectus, agreement), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
