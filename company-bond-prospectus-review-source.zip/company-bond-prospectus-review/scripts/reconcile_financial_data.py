#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from typing import Any

from calculate_financial_metrics import check_equation
from common import convert_unit


def reconcile_pair(
    left: dict[str, Any],
    right: dict[str, Any],
    tolerance: Any = "0.01",
    comparison_unit: str = "万元",
) -> dict[str, Any]:
    required = {"value", "unit", "document", "location"}
    if not required <= left.keys() or not required <= right.keys():
        return {
            "status": "insufficient_data",
            "manual_review_required": True,
            "reason": "missing_value_unit_or_evidence",
        }
    left_normalized = convert_unit(left["value"], left["unit"], comparison_unit)
    right_normalized = convert_unit(right["value"], right["unit"], comparison_unit)
    result = check_equation(left_normalized, [right_normalized], tolerance)
    result["comparison_unit"] = comparison_unit
    result.update(
        {
            "left_evidence": {
                "document": left["document"],
                "location": left["location"],
                "value": str(left["value"]),
                "unit": left["unit"],
            },
            "right_evidence": {
                "document": right["document"],
                "location": right["location"],
                "value": str(right["value"]),
                "unit": right["unit"],
            },
            "manual_review_required": result["status"] == "error"
            and bool(left.get("ocr_conflict") or right.get("ocr_conflict")),
        }
    )
    if left.get("ocr_conflict") or right.get("ocr_conflict"):
        result["status"] = "ocr_conflict"
        result["manual_review_required"] = True
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("left_json")
    parser.add_argument("right_json")
    args = parser.parse_args()
    print(
        json.dumps(
            reconcile_pair(json.loads(args.left_json), json.loads(args.right_json)), ensure_ascii=False, indent=2
        )
    )


if __name__ == "__main__":
    main()
