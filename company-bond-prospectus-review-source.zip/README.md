# company-bond-prospectus-review

将 Dify DSL 0.6.0 的公司债募集说明书审核工作流迁移为可安装的 Codex/ChatGPT Work Skill。仓库包含完整迁移库存、逐节点映射、规则、确定性 Python 脚本、Schema、测试和打包工具；源 Dify YML 不进入安装包。

## 安装

解压 `dist/company-bond-prospectus-review.zip`，将其中的 `company-bond-prospectus-review` 文件夹复制到 `$CODEX_HOME/skills/`（未设置时通常为 `~/.codex/skills/`），重启或刷新 Codex 后调用 `$company-bond-prospectus-review`。

## 开发

```powershell
python -m pip install -e ".[dev]"
python -m pytest
python C:\Users\Kudo\.codex\skills\.system\skill-creator\scripts\quick_validate.py .\company-bond-prospectus-review
python .\tools\package_skill.py
```

## 目录

- `company-bond-prospectus-review/`：可安装 Skill。
- `build/dify_inventory.json`：完整机器库存（含全部节点配置、Prompt、代码和连线）。
- `docs/`：架构、迁移映射、决策、限制和盲测指南。
- `tests/`：结构、单元和合成案例测试。
- `tools/`：Dify 分析与 ZIP 打包工具。

## 调用示例

```text
Use $company-bond-prospectus-review 对这些募集说明书和审计报告执行深度审核，输出 Markdown 报告。
```

```text
Use $company-bond-prospectus-review 只做低级错误与数据一致性专项核查，列出原文证据和修改建议。
```

```text
Use $company-bond-prospectus-review 核对募集说明书与已上传问核表的一致性；没有双侧证据时标记人工复核。
```
