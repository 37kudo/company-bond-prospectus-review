# 设计决策

- 使用官方 `skill-creator` 初始化器和 `agents/openai.yaml`，不创建旧式 manifest。
- Skill 本体不包含 README/CHANGELOG；这些工程文件保留在仓库根目录。
- 保留每个 LLM 节点的专项内容，同时把证据、禁止臆测、误报排除和输出结构提取为公共 references。
- 以当前 Codex/ChatGPT Work 会话执行语义审核，脚本不调用外部模型。
- 财务计算使用 Decimal；尾差状态分为 match、rounding_difference、error、insufficient_data 和 ocr_conflict。
- 用户缩小范围时仍强制运行适用范围识别、低级错误专项、证据校验和去重。
- 缺少可选外部材料只记录未执行原因，不生成虚假披露缺失。
- 源工作流、完整 inventory 和测试不放入安装 ZIP，降低敏感信息和开发文件泄露风险。

