# Dify 到 OpenAI Skill 独立迁移审计（2026-07-17）

## 审计基准

- 独立读取源文件：`公司债募集说明书智能审核.yml`（用户指定的 `(1)` 文件名在工作区中不存在；Downloads 中发现同尺寸源副本）。
- 文件大小：784,578 字节。
- SHA-256：`1731db598e4c5b4280e08065fbb2527f70a8ee2dabaf497ee3dcbb58045bc46c`。
- DSL 版本：`0.6.0`。
- 独立解析未调用现有 inventory/migration map；解析完成后才进行逐项比较。

## 独立解析结果

| 项目 | 数量/结果 |
|---|---:|
| 节点 | 199 |
| 连线 | 451 |
| LLM | 43 |
| code | 64（22 个实质节点、42 个 `__skip` 节点） |
| if-else | 42 |
| variable-aggregator | 42 |
| document-extractor | 4 |
| iteration / iteration-start | 1 / 1 |
| start / end | 1 / 1 |
| LLM Prompt 总字符数 | 114,184 |
| code 总字符数 | 160,062 |

### 输入变量

源 start 节点共 8 个输入：`prospectus_file`、`review_mode`、`output_format`、`manual_focus`、`selected_chapters`、`audit_report_file`（多文件）、`trustee_agreement_file`、`holders_meeting_rules_file`。

源扩展名支持：募集说明书 `.pdf/.doc/.docx/.txt/.md`；审计报告额外支持 `.png/.jpg/.jpeg`；受托协议和持有人会议规则支持 `.pdf/.doc/.docx/.txt/.md`。

### 外部文件与解析

4 个文档解析节点分别解析募集说明书、逐份审计报告、受托管理协议和持有人会议规则。审计报告通过 1 个 iteration 逐份处理。目标 Skill 在此基础上扩展支持法律意见书、核查意见、问核表、反馈回复、评级报告、批复、章程、合同和其他底稿；这些扩展不是源 start 节点原生输入字段，而是目标 Skill 的通用多文件能力。

### 条件与聚合

42 个条件节点均检查 `review_router.enabled_nodes` 是否包含对应 `|task_id|`。42 个变量聚合器均在实际 LLM 输出与对应 skip 输出之间二选一。目标统一路由必须同时保持源快速模式集合、章节别名展开、适用范围停止、无增信跳过和未执行原因语义。

### 最终输出

源 end 节点只有 1 个字段：`result`，来源为 `report_clean.result`，类型为 string。目标 Skill 额外提供结构化报告字段 `mode`、`summary`、`issues`、`task_status`、`limitations`，并保留 Markdown/JSON/Word 大纲三种输出形式。

## 与现有清单比较

| 对象 | 比较结论 |
|---|---|
| `build/dify_inventory.json` | 节点数、连线数、类型数量、199 个节点 ID、全部节点 `data/config`、451 条 edge 均与源 YAML 相同；无悬空边。 |
| `docs/dify-workflow-inventory.md` | 总量和逐节点清单一致；详细 Prompt/code/条件/聚合原配置保存在 JSON inventory。 |
| `docs/migration-map.md` | 199 个源节点均有映射行；原先对多个实质 code 节点使用“已迁移”过于乐观，现已将未逐行等价节点改为“部分迁移”。 |
| 43 个规则文件 | 独立比较确认 43 个源 LLM 的 system/user Prompt 经公共重复约束剥离后的独有文本均存在，缺失数为 0。 |

## 原始问题、严重程度与处理

### P1

1. `scripts/route_tasks.py` / `tools/analyze_dify.py`：目标快速模式集合与源 `review_router` 不一致，错误包含 `finance_tasks`，并遗漏声明、风险、资产、现金流等任务；已修复为源集合并增加回归测试。
2. `scripts/route_tasks.py` / `config/review_tasks.yaml`：指定“第四节”或“第五节”时无法命中细分专项，导致应执行任务被跳过；已为专项任务增加父章节和中文模块别名。
3. 43 个规则文件：Prompt 保留了 78 种 Dify 变量选择器，但目标运行时没有来源契约；已新增 `references/context-contract.md` 并在 `SKILL.md` 强制加载。
4. `validate_issues.py` / `issue.schema.json`：跨文件双侧证据只校验一个非空字符串，且包含“募集说明书”的混合 document 字符串可绕过未上传文件检查；已改为 `left/right/difference` 结构并逐侧核验已上传文件。
5. `reconcile_financial_data.py`：尾差阈值按左侧单位解释，`0.01 亿元` 会错误容忍 100 万元差异；已统一换算到万元后使用 Decimal 比较。
6. `calculate_financial_metrics.py`：相较源 `finance_code` 缺少非流动资产占比、有息债务短期占比、现金流覆盖、EBITDA 利息保障、周转率、贷款/利息偿付率和授信余额等确定性计算；已补齐常见公式，仍要求以募集说明书实际披露公式为准。
7. `docs/migration-map.md`：多个实质代码节点仅有目标文件标题映射，却被标成“已迁移”；已改为诚实的“部分迁移”，并新增财务记录和受托条款比较脚本。源 Dify 专用长文本召回/表格恢复仍列为真实项目验证项。
8. `build_report.py` / `report.schema.json`：JSON CLI 只输出 `issues`，不满足自身要求的 `mode/task_status/limitations`；已统一输出完整报告对象和摘要。
9. `low_level_review.md`：源 Prompt 在指定其他章节时要求输出空结果，与目标“始终单列并执行低级错误专项”设计冲突；已增加优先级明确的迁移覆盖规则。
10. `config/review_tasks.yaml`：标准模式文档描述会核对已上传外部材料，但派生跨文件任务仅允许深度模式；已允许标准和深度模式，并继续以文件实际上传为前提。

### P2

1. `agents/openai.yaml`：界面中文字段为损坏编码；已重建为有效 UTF-8，并符合当前 `openai.yaml` 字段规范。
2. `tests/conftest.py`：直接执行 `pytest` 时根目录未加入 import path，测试收集失败；已修复，并将 README 命令统一为 `python -m pytest`。
3. 原测试只断言节点“有映射”、文件“存在”，未检验源快速集合、父章节路由、双侧证据、单位阈值和扩展财务公式；已增加对应回归测试。
4. 输入文件支持分散在描述和角色正则中；已新增 `references/input-contract.md`，明确必需/可选角色、常见格式、逐份审计报告和视觉/OCR 降级策略。

### P3

1. 后续可为复杂 PDF 表格增加更多真实版式基准样本，并对页码/表名定位准确率建立量化指标。
2. 后续可直接生成 `.docx`；当前“Word 大纲”仍是 Markdown 层级文本。

## 尚未完全修复

- 源 `doc_retrieval`、`financial_data_extract`、`financial_note_compare`、`prospectus_ch5_table_compare` 和 `report_clean` 含大量 Dify 特定 Markdown 表格解析、上下文截断和容错代码。目标已迁移业务契约、关键 Decimal 核对、来源保真和报告结构，但未逐行复刻 160,062 字符代码；强行逐行搬运会重新引入 Dify 上下文形态和脆弱字符串管道。该部分标记为“部分迁移”，需用真实长文档盲测验证。
- 扫描件、复杂合并单元格、OCR 串行、超长募集说明书的章节召回和页级定位取决于当前会话原生读取/视觉能力；不强制依赖 MinerU，也未内置外部 OCR。
- 监管规则及时效性、不同交易所模板和项目组自定义口径需要持续维护，无法仅凭源 DSL 静态验证。

## 覆盖率口径

- 节点清单覆盖：199/199 = 100%。
- 连线与配置留档覆盖：451/451，199/199 = 100%。
- LLM 独有 Prompt 文本覆盖：43/43 = 100%。
- 任务/规则文件覆盖：43/43 = 100%；另有 9 个跨文件派生任务。
- code 节点映射覆盖：64/64 = 100%；其中 42 个 skip 节点语义合并，22 个实质节点均有目标职责，但部分节点未逐行等价。
- 映射状态中“已迁移/已合并/原生能力替代”为 180/199 = 90.5%，另有 19/199 = 9.5% 明确标记“部分迁移”。节点职责覆盖仍为 100%，但不把部分迁移计作等价完成。该比例不等于真实项目准确率；剩余风险集中在复杂文档召回、表格恢复和最终清洗容错。

## 盲测建议

建议进入“受控盲测”，不建议直接生产放行。至少选取 3 类项目：纯文本 PDF、含多份审计报告的复杂表格项目、扫描/OCR 项目；分别验证任务执行率、双侧证据率、财务重算一致率、误报率、漏报率、定位准确率和报告可修改性。
